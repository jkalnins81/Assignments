using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Projectile : MonoBehaviour
{
    float projectileSpeed;
    GameObject enemyDeathSoundGO;
    AudioSource enemyDeathSound;

    void Start()
    {
        projectileSpeed = 20;
        enemyDeathSoundGO = GameObject.Find("EnemyDeathSound");
        enemyDeathSound = enemyDeathSoundGO.GetComponent<AudioSource>();
    }

    
    void Update()

    {
        transform.Translate(Vector2.up * Time.deltaTime * projectileSpeed);

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Enemy"))
        {
            enemyDeathSound.Play();
            Destroy(gameObject);
            //SceneManager.LoadScene("SampleScene");
        }

    }

}

