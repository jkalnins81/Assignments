using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    
    private Rigidbody2D rb2d;
    private SpriteRenderer playerSpriteRenderer;

    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        playerSpriteRenderer = GetComponent<SpriteRenderer>();
    }
    
    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float y = Input.GetAxis("Vertical");

        Vector2 movement = new Vector2(x, y) * speed;

        rb2d.velocity = movement;

        if (x > 0)
        {
            playerSpriteRenderer.flipX = false;
        }

        if (x < 0)
        {
            playerSpriteRenderer.flipX = true;
        }
    }
}

