using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    //public bool jump;
    private Rigidbody2D rb2d;
    private SpriteRenderer playerSpriteRenderer;
    public Animator playerAnimator;
    public GroundCollision groundCollision;
    

    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        playerSpriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void OnLanding()
    {
        playerAnimator.SetBool("IsJumping", false);
    }

    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        
        playerAnimator.SetFloat("Speed", Mathf.Abs(x));

        //We don't need to multiply with Time.deltaTime since it's already the right unit.
        Vector2 movement = new Vector2(x, 0) * speed;

        rb2d.velocity = movement;

        if (Input.GetButton("Jump") && groundCollision.isGrounded)
        {
            //jump = true;
            playerAnimator.SetBool("IsJumping", true);
            rb2d.AddForce(Vector2.up * 15, ForceMode2D.Impulse);
        }

        //else jump = false;

        if (x > 0)
        {
            playerSpriteRenderer.flipX = false;
        } 

        if(x < 0)
        {
            playerSpriteRenderer.flipX = true;
        }

    }
}
